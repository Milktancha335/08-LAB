// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyBeHP7RHoRo9sTc-CgmxxI-Kp_cVKdZPHA",
  authDomain: "milukuchan07.firebaseapp.com",
  projectId: "milukuchan07",
  storageBucket: "milukuchan07.appspot.com",
  messagingSenderId: "666198138221",
  appId: "1:666198138221:web:1f864bd78fdcdb8c58ce64",
  measurementId: "G-00C282XQCN",
});

const db = getFirestore(firebaseApp);
export default db;
